##########
`MIFS` API
##########

This is the full API documentation of the `MIFS` toolbox.

.. _mifs_ref:

MIFS methods
============

.. automodule:: mifs
    :no-members:
    :no-inherited-members:

Classes
-------
.. currentmodule:: mifs

.. autosummary::
   :toctree: generated/

   MutualInformationFeatureSelector
